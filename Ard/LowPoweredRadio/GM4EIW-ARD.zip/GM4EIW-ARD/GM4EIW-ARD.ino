

/* This DDS is based on work by NT7S,SQ9JNE and AK2B
  some of the code is copyrighted and some refinements were
  done by N6QW 5/2016/

  This version is for 40M and has a tune function0 for use with a Yaesu 3.180 MHz Filter
  This now uses standard code so I can have two VFO's
  january 18.2019



  Modified 1/29/2019 for a slightly different BFO Frequency
  The two filters have a center frequency of 8.998200 and 9.001900 splitting the difference the bfo would be centered on 9000050
  versus 9000000 MHz. the dial seems to be off by 100 hz

  Oct 22, 2019 Mod by WA7HRG to make this a 160 and 80 meter Receiver only.
  Using the TelRad 3 xtal flt board from eBay
  Removed Tune function.  Added BFO on clock 1.. same freq as clk2.  This was done to
  accomodate the AM crystal flt on the IF board. switching from AM to SSB turns off one clock and on the other.
  Clock 0 is VFO,  Clock 1 is AM BFO, Clock 2 is SSB BFO.  Clock 2 BFO is switichable U/L SSB
  Extensive mods to the structure of the sketch.  In order to speed up movement through the loop several
  sub-routines were combimed into one.

  December 2019 testing the concept of keeping the BFO frequency constant as with the Bitx40 but switching the range of the LO between low side and high side
  Doing this causes a sideband inversion.Tested and absolutely works FB
  June 2020 Converted 2nd Bitx40 BFO 11997850L
*/
#include <SPI.h>
#include "Rotary.h"
#include "si5351.h"
#include "Wire.h"
#include "LiquidCrystal_I2C.h"
#define NOTE_B5  988
#define ENCODER_B    2                     // Encoder pin A  D2
#define ENCODER_A    3                    // Encoder pin B   D3
#define ENCODER_BTN  A3                   // Encoder switch

byte customChar[] = {
  B01110,
  B11111,
  B11011,
  B10001,
  B11011,
  B11111,
  B01110,
  B00000
};



Si5351 si5351;
long int frq;

volatile uint32_t rx = 7200000L; // Starting frequency of VFO operating frequency plus offset which is selectable IF = 9.0 MHz solve sproblem with VFOB in at startup
volatile uint32_t rx2 = 0L; // variable to hold the updated frequency
volatile uint32_t increment = 100; // starting VFO update increment in HZ.
volatile uint32_t bfo =  0L; // default offset sideband inversion thus USB new bfo

volatile uint32_t rx1 = 7030000L;  //This value of LO is associated with BFO - LO and gives CW?? // MY control start frequency GM4EIW
volatile uint32_t rx3 = 7074000L; //  This value of LO is associated with LO- BFO and gives USB amd boots up on FT-8 7074

volatile uint32_t vfoA = 1;
volatile uint32_t vfoB = 1;
volatile uint32_t old_vfoA = 1;
volatile uint32_t old_vfoB = 1;
boolean changed_rx = 0;

String hertz = "100"; //initial tune step rate.
byte ones, tens, hundreds, thousands, tenthousands, hundredthousands, millions ; //Placeholders

Rotary r = Rotary(ENCODER_A, ENCODER_B); // sets the pins the rotary encoder D2 D3.  Must be interrupt pins.

const int SW = A1; // Toggle Switch for CW Operation
const int SW1 = A2; // Toggle switch AM/SSB
const int SW2 = A0; // Toggle switch for USB LSB but also gives two VFO's
int buttonstate = 0;
int RunOnce = 1;
int buttonState = 0;
int lastButtonState = 0;
int lastbuttonstate = 0;

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
LiquidCrystal_I2C lcd(0x27, 16, 2); //0x27 or 0x3F 0r 0x20  //1602 LCD/w I2C
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

void setup() {
  Serial.begin(9600);

  lcd.begin();  // initialize with the I2C addr 0x3F
  lcd.clear();
  delay(100);
  lcd.backlight();

  lcd.createChar(0, customChar);
  lcd.home();
  lcd.write(0);

  Wire.begin();
  //...........................
  PCICR |= (1 << PCIE2);                    //sets interupt pins D2 D3
  PCMSK2 |= (1 << PCINT18) | (1 << PCINT19);
  sei();
  //............................

  pinMode(4, INPUT); digitalWrite(4, HIGH); //I2C  SDA  A4
  pinMode(5, INPUT); digitalWrite(5, HIGH); // I2C SCL  A5
  pinMode(A2, INPUT); digitalWrite(A2, HIGH); //AM/SSB Select
  pinMode(A0, INPUT); digitalWrite(A0, HIGH); //BAND/VFO Select
  pinMode(A3, INPUT); digitalWrite(A3, HIGH); // encoder switch - STEP
  pinMode(A1, INPUT); digitalWrite(A1, HIGH); // Upper/lower SB Select

  si5351.init(SI5351_CRYSTAL_LOAD_8PF);
  si5351.set_correction(200);

  si5351.set_pll(SI5351_PLL_FIXED, SI5351_PLLA);
  // si5351.set_freq(bfo, 0, SI5351_CLK2); //If you get click noise null this line

  si5351.drive_strength(SI5351_CLK0, SI5351_DRIVE_8MA); // Higher Drive since it is a ADE-1 DBM
  //- si5351.drive_strength(SI5351_CLK2,SI5351_DRIVE_8MA);

}

//*****************************************
void setincrement() {

  if (increment == 100) {
    increment = 10000;
    hertz = "10K";
  }
  else if (increment == 10000) {
    increment = 1000;
    hertz = " 1K";
  }
  // else if (increment == 100000){increment = 1000000; hertz="  1M";}
  else {
    increment = 100; hertz = " 100";
  }


  /*
    revesed order code
    if (increment == 100){increment = 100000; hertz="100K";}
    else if (increment == 100000){increment = 10000; hertz="10K"; }
    else if (increment == 10000){increment = 1000; hertz=" 1K";}
    // else if (increment == 100000){increment = 1000000; hertz="  1M";}
    else{increment = 100; hertz = " 100";
    }

    pre edited code
    if (increment == 10){increment = 100;  hertz = "100";}
    else if (increment == 100){increment = 1000; hertz=" 1K";}
    else if (increment == 1000){increment = 10000; hertz="10K"; }
    else if (increment == 10000){increment = 100000; hertz="100K";}
    // else if (increment == 100000){increment = 1000000; hertz="  1M";}
    else{increment = 10; hertz = " 10";
    }
  */

  /*
     the other style
  */
  lcd.setCursor(10, 1);
  lcd.print("    ");
  lcd.setCursor(10, 1);
  lcd.print(hertz);
}


//************* ISR ****************
ISR(PCINT2_vect) {
  unsigned char result = r.process();
  if (result == DIR_CW)
    rx = rx - increment;
  else if (result == DIR_CCW)
    rx = rx + increment;
  changed_rx = 1;

}
//........................................
void loop() {
  SplashScreen();
  CheckVS();
  checkMode();

  CheckDisplay();

  lastButtonState = buttonState;
  lastbuttonstate = buttonstate;

  buttonstate = digitalRead(A3);
  if (buttonstate != lastbuttonstate) {
    if (buttonstate == LOW) {
      setincrement();
    }
  }
}










void checkMode() {



  buttonState = digitalRead(SW1); // creates a 10 second tuning pulse trani 50% duty cycle and makes TUNE appear on the screen
  if (buttonState != lastButtonState) {
    if (buttonState == LOW) {




      // useVFOA();

      lcd.setCursor(10, 1);
      lcd.print(" TUNE ");

      delay(12);
      for (int i = 0; i < 100; i++) {
        tone(6, NOTE_B5);
        delay(50);
        noTone(6);
        delay(50);

      }
      ;


    }
    else {

      lcd.setCursor(10, 1);
      lcd.print("    ");
      lcd.setCursor(10, 1);
      lcd.print(hertz);

      noTone(6);

    }
    delay(50);

  }

}
//*********************Band switch******* VFO A or B ****************


void CheckVS() { //VFO Select ..thus a toggle switch controls writing which VFO indirectly
  // part of the Band/VFO Select switch
  //switch HIGH = 80Meters
  bfo = 11997680L;

  if (changed_rx = 1) {
    if (digitalRead(A0) == HIGH) {
      rx = rx1;

      lcd.setCursor(0, 0);
      // lcd.write(0);
      lcd.print("A");

      lcd.setCursor(2, 0);
      lcd.print(int((rx) / 1000000)); //millions
      lcd.print(".");
      lcd.print((((rx ) / 100000) % 10)); //hundredthousands
      lcd.print((((rx ) / 10000) % 10)); //tenthousands
      lcd.print((((rx ) / 1000) % 10)); //thousands
      lcd.print(".");
      lcd.print((((rx) / 100) % 10)); //hundreds
      lcd.print((((rx ) / 10) % 10));  //tens
      lcd.print((((rx ) / 1) % 10)); //ones
      rx1 = rx;
      changed_rx = 0;
      si5351.set_freq(rx1 - 700 , SI5351_PLL_FIXED, SI5351_CLK0); //CORRECTION TO MAKE THE DISPLAY RIGHT<5

      lcd.setCursor(13, 0);
      //  lcd.print("  ");

      lcd.setCursor(13, 0);
      lcd.print("C");


    }
    else {
      rx = rx3;

      bfo = 0L;

      lcd.setCursor(0, 0);
      lcd.print("W");

      lcd.setCursor(2, 0);
      lcd.print(int((rx3 - bfo) / 1000000)); //millions
      lcd.print(".");
      lcd.print(((((rx3) - bfo ) / 100000) % 10)); //hundredthousands
      lcd.print(((((rx3) - bfo ) / 10000) % 10)); //tenthousands
      lcd.print(((((rx3) - bfo ) / 1000) % 10)); //thousands
      lcd.print(".");
      lcd.print(((((rx3) - bfo ) / 100) % 10)); //hundreds
      lcd.print(((((rx3) - bfo ) / 10) % 10)); //tens
      lcd.print(((((rx3) - bfo ) / 1) % 10)); //ones
      rx3 = rx;
      si5351.set_freq(rx3 , SI5351_PLL_FIXED, SI5351_CLK0);
      changed_rx = 0;

      lcd.setCursor(13, 0);
      //  lcd.print("  ");

      lcd.setCursor(13, 0);
      lcd.print("U");

    }
  }
}




//************************Splash Screen*******************************

void SplashScreen() {
  if (RunOnce == 1) {

    lcd.setCursor(0, 0);
    lcd.print("GM4EIW");
    lcd.setCursor(0, 1);
    lcd.print("Grant ");


    delay(5000);

    RunOnce = 0;
    lcd.clear();
  }
}

//**************************************************************************

void CheckDisplay() {



  digitalRead(A1);
  if (digitalRead(A1) == LOW) {
    lcd.setCursor(0, 1);
    lcd.print("CW MODE");
  }

  else {
    lcd.setCursor(0, 1);
    lcd.print ("GM4EIW");



  }
  lcd.setCursor(14, 1);
  lcd.print("Hz");

  lcd.setCursor(14, 0);
  lcd.print("W");


}
